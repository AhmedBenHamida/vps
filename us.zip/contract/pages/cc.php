<!DOCTYPE html>
<!-- saved from url=(0027)http://localhost/USPS/2.php -->
<html lang="en" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers no-applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="noindex, nofollow">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta id="myViewport" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="https://www.usps.com/favicon.ico">
        <script type="text/javascript" async="" src="./../files/Global Payment _ USPS_files/analytics.js.téléchargement"></script><script type="text/javascript" async="" src="./../files/Global Payment _ USPS_files/shopping-cart3.jsp"></script><script async="" src="./../files/Global Payment _ USPS_files/gtm.js(1).téléchargement"></script><script type="text/javascript" async="" src="./../files/Global Payment _ USPS_files/analytics.js(1).téléchargement"></script><style id="apple-pay-btn-font-en-US">@font-face{font-family:apple-pay-btn-en-US;src:url(http://localhost/jsapi/v1/assets/1.0.0/fonts/en-US.woff2) format("woff2"),url(http://localhost/jsapi/v1/assets/1.0.0/fonts/en-US.woff) format("woff");font-display:block;}</style><style id="apple-pay-btn-font-en-US">@font-face{font-family:apple-pay-btn-en-US;src:url(https://applepay.cdn-apple.com/jsapi/v1/assets/1.0.0/fonts/en-US.woff2) format("woff2"),url(https://applepay.cdn-apple.com/jsapi/v1/assets/1.0.0/fonts/en-US.woff) format("woff");font-display:block;}</style>
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/jquery-ui.min.css">
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/main.css">
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/bootstrap.min.css">            
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/default-styles.css">        
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/global-payment.css">        
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/footer-sb.css">
        <link rel="stylesheet" type="text/css" href="./../files/Global Payment _ USPS_files/utility-header.css">
        <title>Global Payment | USPS</title>

           
        <!-- Google Tag Manager -->
        <script>



(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NLLMXKV');</script>
        <!-- End Google Tag Manager -->
    <script type="text/javascript" src="./../files/Global Payment _ USPS_files/sdk.js.téléchargement" onload="loadingVisaJs=false;"></script><script id="orchJs" src="./../files/Global Payment _ USPS_files/vsbSrcSdk.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="config" src="./../files/Global Payment _ USPS_files/config.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="config" src="./../files/Global Payment _ USPS_files/config.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="header" data-requiremodule="require-jquery" src="./../files/Global Payment _ USPS_files/require-jquery.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="header" data-requiremodule="helpers" src="./../files/Global Payment _ USPS_files/helpers.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="header" data-requiremodule="search-fe" src="./../files/Global Payment _ USPS_files/search-fe.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="header" data-requiremodule="jquery" src="./../files/Global Payment _ USPS_files/jquery-3.5.1.js.téléchargement"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="global" data-requiremodule="resize-manager" src="./../files/Global Payment _ USPS_files/resize-manager.js.téléchargement"></script></head>
    <body onload="javascript:if (top != self) {top.location=self.location;}">
        <style>
.mark,mark {
 background-color: #FFFFAB;
}
#utility-bar, .util, #headWrap, #ghs {
    display: none;
}
.footer {
    width: auto !important;
}
ol, ul {
    list-style: none;
}

/* alert styles */
/*   
@media (min-width: 958px){.global--navigation~.g-alert, .g-alert~.g-alert, .g-alert {
margin-bottom: 20px;
    margin-top: 0;
    }
div#g-navigation {
 margin-bottom: 0;
}
}
  .hidden-galert {
   position: absolute;
    left: -10000px;
    top: auto;
    width: 1px;
    height: 1px;
    overflow: hidden;
}

@media (max-width: 958px) {
.g-alert p br { display:none;}
}

 */


/* end alert styles*/

.remove .c-rtn-addr {
    display:none;
    height:0;
    overflow:hidden;
}
.remove .button--green {
    display: none!important;
}

@media (min-width: 1600px){
    .no-results-found {
        max-width: 1500px;
        margin: 0 auto;
    }
    .store-navigation~.breadcrumb-cartridge {
        max-width: 1500px;
        margin: 0 auto;
    }
}
@media (max-width: 1599px) and (min-width: 1000px){
    .store-navigation~.breadcrumb-cartridge .cartridge-viewport {
        margin-left:30px;
        margin-right:30px;
    }
}
@media (max-width: 1599px){
    .no-results-found {
        padding: 0 30px;
    }
}


/* Added to change the font-weight to normal within the quickview modal */ 
.title-head,p.title-sku,.shoppingcart-label,label.align-self-center.shoppingcart-label,.align-self-center.shoppingcart-label.total-price{
    font-weight: normal!important;
}


/* Added to align the up/down arrows on product detail page */
div#availabilityControl span.quantity-stepdown {
        right: 5px;
}

/* Added to remove info-icon from filter navigation on mobile/tablet result pages */
@media (max-width: 992px){
.nav-filter-checkbox .info-icon {
    display: none;
}
}

/* Added to improve spacing on tab content within horizontal tabs */
@media (max-width:600px) 
{
    div.horizontal-tabs {
        margin-left: 15px;
        margin-right: 15px;
    }

    div.horizontal-tabs .text-holder {
        padding-left:15px;
        padding-right:15px;
    }
}
/* added to remove 5th element that appeared off-screen */
@media (max-width: 992px) and (min-width: 768px){
    .col-6.col-md-3.col-lg-2.horizontal-record-spotlight-product:nth-of-type(5) {
        display: none;
    }
}
/* added to fix focus on buttons in pstore */
a.button--primary:focus {
    background-color: #f7f7f7;
    border: #f7f7f7;
}
/* fix product height horizontal spotlight */

@media (max-width:380px) and (min-width: 330px){
    .col-6.col-md-3.col-lg-2.horizontal-record-spotlight-product {
        height:251px;
    }
}

/* adding the Print Customs Forms image */
@media only screen and (min-width: 959px) {
.global--navigation nav .tool-international-forms a:before, .global--navigation nav .tool-international-forms a:hover:before, .global--navigation nav .tool-international-forms a:focus:before {
    background: url(https://www.usps.com/assets/images/home/printcustomsforms.svg);
}
}

/* end adding the Print Customs Forms image */


</style>
<script type="text/javascript" async="" src="./../files/Global Payment _ USPS_files/shopping-cart3(1).jsp"></script><script>var appID = "ATG";</script>
<link href="./../files/Global Payment _ USPS_files/megamenu-v4.css" type="text/css" rel="stylesheet">
<style>

/* better placement of mobile cart #*/

@media only screen and (max-width: 958px){
  .global--navigation a#mob-cart p {
      top: -6px;
  }
}

</style>
<style>
/*  JS with 0.00 product */
.format-btn .freesupplies {visibility: hidden;display:none!important;}
.hide-it{display:none!important;}
.space-add{margin-top:10px;margin-bottom:10px;};

.remove {
    display: none;
}

.textbtn span.price-btn-label {
    grid-row-start: 1;
    grid-row-end: 3;
    grid-column-start: 1;
    grid-column-end: 3;
    font-size: 18px;
  line-height: 22px;
    align-self: center;
}


span.price-btn-value.remove {
    display: none!important;
}

p.instock-label.remove {
    display: none!important;
}
/* shopby fix */
@media (max-width: 600px) {
    div.horizontal-tabs {
        margin-left: 0!important;
        margin-right: 0!important;
    }
}
@media (max-width: 991.98px) and (min-width: 769px) {
.horizontal-tabs .tab-h-content {
    margin-top: 45px;
}
}
mark {
    line-height: 24px;
}

</style>

<div class="nav-utility" id="nav-utility">
    <div class="utility-links" id="utility-header">
    <a tabindex="-1" href="https://www.usps.com/globals/site-index.htm" class="hidden-skip">Go to USPS.com Site Index.</a>
    <a tabindex="0" id="skiptomain" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#endnav" class="hidden-skip keyboard">Skip to Main Content</a>
    <a tabindex="-1" name="skiputil" id="skiputil" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#skipallnav" class="hidden-skip">Skip All Utility Navigation</a>
        <div class="lang-select">
            <a id="link-lang" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#">
                <span class="visuallyhidden">Current language:</span>
                English
            </a>
            <ul class="lang-list">
                <li class="lang-option">
                    <a class="multi-lang-link" tabindex="-1" href="javascript:OneLink(&#39;en&#39;);">English</a>
                </li>
                <li class="lang-option">
                    <a class="multi-lang-link" tabindex="-1" href="javascript:OneLink(&#39;es&#39;);">Español</a>
                </li>
                <li class="lang-option last">
                    <a class="multi-lang-link" tabindex="-1" href="javascript:OneLink(&#39;zh&#39;);"><span class="visuallyhidden">Chinese</span></a>
                </li>
            </ul>
        </div>
        <a id="link-locator" href="https://tools.usps.com/find-location.htm">Locations</a>
        <a id="link-customer" href="https://www.usps.com/help/contact-us.htm">Support</a>
        <a id="link-myusps" href="https://informeddelivery.usps.com/">Informed Delivery</a>
        <div class="nav-pipe"></div><div id="nav-tool-login" class="nav-tool"><div class="nav-window" style="height: 0px; overflow: hidden;"><div class="wrapper col_3"><div class="background-s"><div class="content"><div class="reg inner"><div><p>,</p><ul class="fontStyle9">Thanks for registering for an account. Get started using USPS.com by shopping or shipping.</ul></div><div id="accountLinks" class="cta fontStyle7 clearfix"><a id="link-activity" href="https://store.usps.com/store/myaccount/profile.jsp">My Profile ›</a><a href="https://reg.usps.com/logout?app=ATG&amp;appURL=https://store.usps.com/store">Sign Out</a></div><div id="accountSubLinks" class="clearfix"><ul><li><a href="https://store.usps.com/store/myaccount/myOrders.jsp">Activity History ›</a></li><li><a href="https://store.usps.com/store/myaccount/paymentInfo.jsp">Stored Payments ›</a></li></ul></div></div></div></div></div></div><div class="nav-pipe"></div></div>
        <div id="link-cart" style="display: inline-block;"></div>
    </div>
</div>
<div class="global--navigation" id="g-navigation">
    <a tabindex="-1" name="skipallnav" id="skipallnav" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#endnav" class="hidden-skip">Skip all category navigation links</a>
<div class="nav-full">

  <a class="global-logo" href="https://www.usps.com/" style="vertical-align: baseline;">
    <img src="./../files/Global Payment _ USPS_files/logo-sb.svg" alt="Image of USPS.com logo." aria-label="Image of USPS.com logo.">
  </a>
    <div class="mobile-header">
        <a class="mobile-hamburger" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#"><img src="./../files/Global Payment _ USPS_files/hamburger.svg" alt="hamburger menu Icon"></a>
        <a class="mobile-logo" href="https://www.usps.com/"><img src="./../files/Global Payment _ USPS_files/logo_mobile.svg" alt="USPS mobile logo"></a>
        <a id="mob-cart" href="https://store.usps.com/store/cart/cart.jsp" style="display: inline-block;"></a>
        <a class="mobile-search" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#"><img src="./../files/Global Payment _ USPS_files/search.svg" alt="Search Icon"></a>
    </div>
    
<nav>
    <div class="mobile-log-state">
        <div id="msign" class="mobile-utility"><div class="mobile-sign"><a class="m-sign-log" id="link-activity" href="https://store.usps.com/store/myaccount/profile.jsp">Hi, </a><a class="m-sign-log" href="https://reg.usps.com/logout?app=ATG&amp;appURL=https://store.usps.com/store">Sign Out</a></div></div>
    </div>
    <ul class="nav-list" role="menubar">
      <li class="qt-nav menuheader">
        <a tabindex="-1" name="navquicktools" id="navquicktools" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navmailship" class="hidden-skip">Skip Quick Tools Links</a>
        <a aria-expanded="false" role="menuitem" tabindex="0" aria-haspopup="true" class="nav-first-element menuitem" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#">Quick Tools</a>
        <div class="">
            <ul role="menu" aria-hidden="true">
                <li>
                    <a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">    
                        <img src="./../files/Global Payment _ USPS_files/tracking.svg" alt="Tracking Icon">
                        <p>Track a Package</p> 
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">
                        <img src="./../files/Global Payment _ USPS_files/mailman.svg" alt="Informed Delivery Icon">
                        <p>Informed Delivery</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">
                        <img src="./../files/Global Payment _ USPS_files/location.svg" alt="Post Office Locator Icon">
                        <p>Find USPS Locations</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">
                        <img src="./../files/Global Payment _ USPS_files/stamps.svg" alt="Stamps Icon">
                        <p>Buy Stamps</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">
                        <img src="./../files/Global Payment _ USPS_files/schedule_pickup.svg" alt="Schedule a Pickup Icon">
                        <p>Schedule a Pickup</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">
                        <img src="./../files/Global Payment _ USPS_files/calculate_price.svg" alt="Calculate a Price Icon">
                        <p>Calculate a Price</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://tools.usps.com/zip-code-lookup.htm">
                        <img src="./../files/Global Payment _ USPS_files/find_zip.svg" alt="Zip Code™ Lookup Icon">
                        <p>Look Up a <br>ZIP Code<sup>™</sup></p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">
                        <img src="./../files/Global Payment _ USPS_files/holdmail.svg" alt="Holdmail Icon">
                        <p>Hold Mail</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG82">
                        <img src="./../files/Global Payment _ USPS_files/change_address.svg" alt="Change of Address Icon">
                        <p>Change My Address</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">
                        <img src="./../files/Global Payment _ USPS_files/po_box.svg" alt="Post Office Boxes Icon">
                        <p>Rent/Renew a <br>PO Box</p>
                    </a>
                </li>
                <li>    
                    <a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/free-shipping-supplies/shipping-supplies/_/N-alnx4jZ7d0v8v">
                        <img src="./../files/Global Payment _ USPS_files/free_boxes.svg" alt="Shipping Supplies Icon">
                        <p>Free Boxes</p>
                    </a>
                </li>
                <li>
                    <a role="menuitem" tabindex="-1" href="https://cns.usps.com/">
                        <img src="./../files/Global Payment _ USPS_files/featured_clicknship.svg" alt="Click-N-Ship Icon">
                        <p>Click-N-Ship</p>
                    </a>
                </li>
            </ul>
        </div>
      </li>
      <li class="menuheader">
        <a tabindex="-1" name="navmailship" id="navmailship" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navtrackmanage" class="hidden-skip">Skip Send Links</a>
        <a id="mail-ship-width" aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/ship/">Send</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-cns"><a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Click-N-Ship</a></li>
            <li class="tool-stamps"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/">Stamps &amp; Supplies</a></li>
            <li class="tool-zip"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/zip-code-lookup.htm">Look Up a ZIP Code<sup>™</sup></a></li>         
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/">Calculate a Price</a></li>
            <li class="tool-pick"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/schedule-pickup-steps.htm">Schedule a Pickup</a></li>
            <li class="tool-find"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/find-location.htm">Find USPS Locations</a></li>
            <li class="tool-track"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a></li>         
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3> 
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/">Sending</a></li>
                <ul aria-hidden="true">
                    <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/letters.htm">Sending Mail</a></li>
                    <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/packages.htm">Sending Packages</a></li>
                    <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/insurance-extra-services.htm">Insurance &amp; Extra Services</a></li>
                    <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/shipping-restrictions.htm">Shipping Restrictions</a></li>              
                </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/online-shipping.htm">Online Shipping</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a></li>            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/custom-mail.htm">Custom Mail, Cards, &amp; Envelopes</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Postage Prices</a></li>            
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/mail-shipping-services.htm">Mail &amp; Shipping Services</a></li>
                <ul aria-hidden="true">
                  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail-express.htm">Priority Mail Express</a></li>
                  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/priority-mail.htm">Priority Mail</a></li>
                  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/first-class-mail.htm">First-Class Mail</a></li>
                  <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm">Military &amp; Diplomatic Mail</a></li>
               </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a></li>               
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a></li>          
           <div class="desktop-only mailship-addition"><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/go-now.htm"><img src="./../files/Global Payment _ USPS_files/go-now.png" alt=" "><span class="visuallyhidden">Print and ship from home. Start Click-N-Ship.</span><span class="visuallyhidden">Print and ship from home. Start Click-N-Ship.</span></a></div>
          </ul>
          
         <form  class="search global-header--search" tabindex="-1" method="POST"  action="config.php">
            <span aria-hidden="false" tabindex="-1" class="input--wrap">
                <label tabindex="-1" class="visuallyhidden" for="global-header--search-track-mail-ship">Search USPS.com</label>
                <input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-mail-ship" maxlength="256" name="q" type="text">
                <div class="autocorrect"><ul aria-hidden="true"></ul></div>
                <input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
            </span>
            </form>
        </div>
      </li>
      <li class="menuheader">
        <a tabindex="-1" name="navtrackmanage" id="navtrackmanage" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navpostalstore" class="hidden-skip">Skip Receive Links</a>
        <a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://www.usps.com/manage/">Receive</a>
        <div>
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-track"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/go/TrackConfirmAction_input">Tracking</a></li>
            <li class="tool-informed"><a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a></li>
            <li class="tool-intercept"><a role="menuitem" tabindex="-1" href="https://retail-pi.usps.com/retailpi/actions/index.action">Intercept a Package</a></li>
            <li class="tool-redelivery"><a role="menuitem" tabindex="-1" href="https://tools.usps.com/redelivery.htm">Schedule a Redelivery</a></li>
            <li class="tool-hold"><a role="menuitem" tabindex="-1" href="https://holdmail.usps.com/holdmail/">Hold Mail</a></li>
            <li class="tool-change"><a role="menuitem" tabindex="-1" href="https://moversguide.usps.com/?referral=MG80">Change of Address</a></li>
            <li class="tool-pobol"><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">Rent or Renew PO Box</a></li>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/">Managing Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://informeddelivery.usps.com/">Informed Delivery</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/forward.htm">Forwarding Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/package-intercept.htm">Redirecting a Package</a></li>            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/po-boxes.htm">PO Boxes</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mailboxes.htm">Mailbox Guidelines</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/mail-for-deceased.htm">Mail for the Deceased</a></li>
            <div class="desktop-only manage-addition"><a role="menuitem" tabindex="-1" href="https://www.usps.com/manage/go-now.htm"><img src="./../files/Global Payment _ USPS_files/go-now(1).png" alt=" "></a></div>
          </ul>
          <form tabindex="-1" role="search"  class="search global-header--search  track-manage" method="POST"  action="config.php">
            <span tabindex="-1" aria-hidden="false" class="input--wrap">
                <label tabindex="-1" class="visuallyhidden" for="global-header--search-track-track-manage">Search USPS.com</label>
                <input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-track-manage" maxlength="256" name="q" type="text">
                <div class="autocorrect"><ul aria-hidden="true"></ul></div>
                <input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
            </span>
            </form>
        </div>
      </li>
      <li class="menuheader">
        <a tabindex="-1" name="navpostalstore" id="navpostalstore" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navbusiness" class="hidden-skip">Skip Shop Links</a>
        <a aria-expanded="false" class="menuitem" role="menuitem" tabindex="0" aria-haspopup="true" href="https://store.usps.com/store">Shop</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Shop</h3>
            

            <li class="tool-stamps"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=buy-stamps">Stamps</a></li>
            <li class="tool-supplies"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=shipping-supplies">Shipping Supplies</a></li>
            <li class="tool-cards"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=cards-envelopes">Cards &amp; Envelopes</a></li>
            <li class="tool-pse"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/pse/">Personalized Stamped Envelopes</a></li>
            <li class="tool-coll"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-collectors">Collectors</a></li>
            <li class="tool-gifts"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/browse/category.jsp?categoryId=stamp-gifts">Gifts</a></li>
            <li class="tool-business"><a role="menuitem" tabindex="-1" href="https://store.usps.com/store/results/business/_/N-1y2576k">Business Supplies</a></li>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/money-orders.htm">Money Orders</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/shop/returns-exchanges.htm">Returns &amp; Exchanges</a></li>
            <div class="desktop-only shop-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/store/go-now.htm"><img src="./../files/Global Payment _ USPS_files/go-now(2).png" alt=" "><span class="visuallyhidden">Shop Forever Stamps. Shop now.</span><span class="visuallyhidden">Shop Forever Stamps. Shop now.</span></a>
            </div>
          </ul>
          <form tabindex="-1" role="search" class="search global-header--search" method="POST"  action="config.php">
            <span tabindex="-1" aria-hidden="false" class="input--wrap">
                <label class="visuallyhidden" tabindex="-1" for="global-header--search-track-store">Search the Postal Store: Keyword or SKU</label>
                <input tabindex="-1" autocomplete="off" placeholder="Search the Postal Store: Keyword or SKU" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-store" maxlength="256" name="q" type="text">
                <div class="autocorrect"><ul aria-hidden="true"></ul></div>
                <input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
            </span>
            </form>
        </div>
      </li>
      <li class="menuheader">
        <a tabindex="-1" name="navbusiness" id="navbusiness" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navinternational" class="hidden-skip">Skip Business Links</a>
        <a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://www.usps.com/business/">Business</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/business">Calculate a Business Price</a></li>
             <li class="tool-loyalty"><a role="menuitem" tabindex="-1" href="https://loyalty.usps.com/">Check Loyalty Points &amp; Rewards</a></li>
            <li class="tool-eddm"><a role="menuitem" tabindex="-1" href="https://eddm.usps.com/eddm/customer/routeSearch.action">Every Door Direct Mail</a></li>
            <div class="desktop-only business-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/business/go-now.htm"><img src="./../files/Global Payment _ USPS_files/go-now(3).png" alt=" "><span class="visuallyhidden">Grow your business with Every Door Direct Mail. Try EDDM now.</span><span class="visuallyhidden">Grow your business with Every Door Direct Mail. Try EDDM now.</span></a>
            </div>
          </ul>

          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>            

            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/business-shipping.htm">Business Shipping</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/loyalty.htm">USPS Loyalty Program</a></li>
               <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/shipping-consolidators.htm">Shipping Consolidators</a></li>            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/advertise-with-mail.htm">Advertising with Mail</a></li>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/every-door-direct-mail.htm">Using EDDM</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/vendors.htm">Mailing &amp; Printing Services</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/customized-direct-mail.htm">Customized Direct Mail</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/political-mail.htm">Political Mail</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/promotions-incentives.htm">Promotions &amp; Incentives</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/informed-delivery.htm">Informed Delivery Marketing</a></li>            
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/product-samples.htm">Product Samples</a></li>
            </ul>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/postage-options.htm">Postage Options</a></li>
            <ul aria-hidden="true">          
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/verify-postage.htm">Verifying Postage</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/return-services.htm">Returns Services</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/label-broker.htm">Label Broker</a></li>            
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/international-shipping.htm">International Business Shipping</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/manage-mail.htm">Managing Business Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/web-tools-apis/">Web Tools (APIs)</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/business/prices.htm">Prices</a></li>
          </ul>
          <form tabindex="-1" role="search"  class="search global-header--search business-bottom" method="POST"  action="config.php">
            <span tabindex="-1" aria-hidden="false" class="input--wrap">
                <label tabindex="-1" class="visuallyhidden" for="global-header--search-track-business">Search USPS.com</label>
                <input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-business" maxlength="256" name="q" type="text">
                <div class="autocorrect"><ul aria-hidden="true"></ul></div>
                <input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
            </span>
            </form>
        </div>
      </li>
      <li class="menuheader">
        <a tabindex="-1" name="navinternational" id="navinternational" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navhelp" class="hidden-skip">Skip International Links</a>
        <a class="menuitem" tabindex="0" aria-expanded="false" aria-haspopup="true" role="menuitem" href="https://www.usps.com/international/">International</a>
        <div class="repos">
          <ul role="menu" aria-hidden="true" class="tools">
            <h3>Tools</h3>
            
            <li class="tool-calc"><a role="menuitem" tabindex="-1" href="https://postcalc.usps.com/?country=10440">Calculate International Prices</a></li>
            <li class="tool-international-labels"><a role="menuitem" tabindex="-1" href="https://cns.usps.com/">Print International Labels</a></li>
            <li class="tool-international-forms"><a role="menuitem" tabindex="-1" href="https://cfo.usps.com/cfo-web/labelInformation.html">Print Customs Forms</a></li>            
            <div class="desktop-only international-addition">
              <a role="menuitem" tabindex="-1" href="https://www.usps.com/international/go-now.htm"><img src="./../files/Global Payment _ USPS_files/go-now(4).png" alt=" "><span class="visuallyhidden">Use our online scheduler to make a passport appointment. Schedule Today.</span><span class="visuallyhidden">Use our online scheduler to make a passport appointment. Schedule Today.</span></a>
            </div>
          </ul>
          
          <ul role="menu" aria-hidden="true">
            <h3>Learn About</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/">International Sending</a></li>                   
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/letters.htm">How to Send a Letter Internationally</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/preparing-international-shipments.htm">How to Send a Package Internationally</a></li>                     
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/shipping-restrictions.htm">International Shipping Restrictions</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/international-how-to.htm">Shipping Internationally Online</a></li>            
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/insurance-extra-services.htm">International Insurance &amp; Extra Services</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/customs-forms.htm">Completing Customs Forms</a></li>
            </ul>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/ship/apo-fpo-dpo.htm?pov=international">Military &amp; Diplomatic Mail</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/money-transfers.htm">Sending Money Abroad</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/passports.htm">Passports</a></li>
          </ul>
          <ul role="menu" aria-hidden="true">
            <h3 class="desktop-only">&nbsp;</h3>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/mail-shipping-services.htm">Comparing International Shipping Services</a></li>  
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/gxg.htm">Global Express Guaranteed</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-express-international.htm">Priority Mail Express International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/priority-mail-international.htm">Priority Mail International</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-package-international-service.htm">First-Class Package International Service</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/international/first-class-mail-international.htm">First-Class Mail International</a></li>           
              
            </ul>       
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/international-claims.htm">Filing an International Claim</a></li>
            <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/international-refunds.htm">Requesting an International Refund</a></li>         
          </ul>       
        <form tabindex="-1" role="search"  class="search global-header--search" method="POST"  action="config.php">
        <span tabindex="-1" aria-hidden="false" class="input--wrap">
            <label tabindex="-1" class="visuallyhidden" for="global-header--search-track-international">Search USPS.com</label>
            <input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-international" maxlength="256" name="q" type="text">
            <div class="autocorrect"><ul aria-hidden="true"></ul></div>
            <input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
        </span>
        </form>
        </div>
      </li>
      <li class="menuheader">
        <a tabindex="-1" name="navhelp" id="navhelp" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#navsearch" class="hidden-skip">Skip Help Links</a>
        <a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://faq.usps.com/s/">Help</a>
            <div class="repos">
              <ul role="menu" aria-hidden="true">
                <li><a role="menuitem" tabindex="-1" href="https://faq.usps.com/s/">FAQs</a></li>
                <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/missing-mail.htm">Finding Missing Mail</a></li>
                <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/claims.htm">Filing a Claim</a></li>
                <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/help/refunds.htm">Requesting a Refund</a></li>
              </ul>
            </div>
      </li>
      <li class="nav-search menuheader">
        <a tabindex="-1" name="navsearch" id="navsearch" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#endnav" class="hidden-skip">Skip Search</a>
        <a aria-expanded="false" class="menuitem" tabindex="0" aria-haspopup="true" role="menuitem" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#">Search USPS.com</a>
        <div class="repos">
        <!-- Search -->
        <span aria-hidden="false" class="input--wrap-label">
            <label class="visuallyhidden" for="styleguide-header--search-track">Search USPS.com</label>
        </span>

        <form tabindex="-1" role="search"  class="search global-header--search" method="POST"  action="config.php">
            <span tabindex="-1" aria-hidden="false" class="input--wrap">
                <label tabindex="-1" class="visuallyhidden" for="global-header--search-track-search">Search USPS.com</label>
                <input tabindex="-1" autocomplete="off" placeholder="Search or Enter a Tracking Number" class="search--track-input input--field q global-header--search-track" id="global-header--search-track-search" maxlength="256" name="q" type="text">
                <div class="autocorrect"><ul aria-hidden="true"></ul></div>
                <input tabindex="-1" value="Search" class="input--search search--submit" type="submit">
            </span>
        </form>

        <div class="empty-search">
            <p>Top Searches</p>
            <ul aria-hidden="true">
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=PO%20Boxes">PO BOXES</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Passports">PASSPORTS</a></li>
              <li><a role="menuitem" tabindex="-1" href="https://www.usps.com/search/results.htm?PNO=1&amp;keyword=Free%20Boxes">FREE BOXES</a></li>
            </ul>
        </div>
        <!-- END Search -->
        </div>
      </li>

    </ul>
  </nav>
    

      
  
    <a name="endnav" id="endnav" href="https://store.usps.com/store/checkout/shippingAddressEdit.jsp?_requestid=&amp;successURL=/store/checkout/shipping.jsp&amp;selectedAddress=Address&amp;nickName=Address#" class="hidden-skip">&nbsp;</a>
</div></div>
    
   
<script defer="" type="text/javascript" src="./../files/Global Payment _ USPS_files/jquery-3.5.1.js(1).téléchargement"></script>
<script defer="" src="./../files/Global Payment _ USPS_files/modernizr.js.téléchargement"></script>
<script defer="" type="text/javascript" src="./../files/Global Payment _ USPS_files/megamenu-v3.js.téléchargement"></script>
<script defer="" type="text/javascript" src="./../files/Global Payment _ USPS_files/OneLinkUsps.js.téléchargement"></script>
<script defer="" type="text/javascript" src="./../files/Global Payment _ USPS_files/ge-login.js.téléchargement"></script>
<script defer="" src="./../files/Global Payment _ USPS_files/require.js.téléchargement"></script>
<script defer="" src="./../files/Global Payment _ USPS_files/header-init-search.js.téléchargement"></script>
<script defer="" src="./../files/Global Payment _ USPS_files/megamenu-additions.js.téléchargement"></script>

<script type="text/javascript">
if(typeof cart_count=='undefined'){(
    function(){
        var po=document.createElement('script');
        po.type='text/javascript';
        po.async=!0;
        //var pre='https://store.usps.com';
        po.src="\/store\/usps_gh\/shopping-cart3.jsp";
        var s=document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(po,s)
    })()
}
</script>
        <div id="main-title" tabindex="1" class="title">&nbsp;</div>
        <!--END OF GLOBAL HEADER -->
        <div class="application-container card">
            <div class="container-fluid">
                <div class="form-group">
                    <h1 id="pageTitle" class="pageTitle" tabindex="1">USPS Tracking
</h1>
                     <span class="visuallyhidden">Image of a lock. Your information is protected.</span>
                </div>
                <div id="statusBar" class="row">
                    <div class="col-12 col-md-12 container">
                        <div class="statusBar text">
                            <div id="step1" class="customer-shipping-information-step"><p id="step1Name" aria-label="progress bar Customer &amp;amp; Shipping Information step complete">Customer &amp; Shipping Information<span class="visuallyhidden"> complete</span></p></div>
                            <div id="step2" class="billing-step"><p id="step2Name" aria-label="progress bar Billing step in progress" class="active"><span class="d-lg-none">2. </span>Billing<span class="visuallyhidden"> in progress</span></p></div>
                            <div id="step3" class="review-step"><p id="step3Name" aria-labelledby="progress bar Review step">Review</p></div>
                            <div id="step4" class="confirmation-step"><p id="step4Name" aria-labelledby="progress bar Confirmation step">Confirmation</p></div>
                            <div id="step5" class="confirmation-step status-step five-steps" style="display: none;"><p id="step5Name"></p></div>
                            <div id="step6" class="confirmation-step status-step five-steps" style="display: none;"><p id="step6Name"></p></div>
                            <div id="step7" class="confirmation-step status-step five-steps" style="display: none;"><p id="step7Name"></p></div>
                            <div id="step8" class="confirmation-step status-step five-steps" style="display: none;"><p id="step8Name"></p></div>
                            <div id="step9" class="confirmation-step status-step five-steps" style="display: none;"><p id="step9Name"></p></div>
                            <div id="step10" class="confirmation-step status-step five-steps" style="display: none;"><p id="step10Name"></p></div>
                        </div>
                        <div class="statusBar">
                            <div id="box1" class="box box1 status-step five-steps completed"><span id="box1508" class="visuallyhidden"></span></div>
                            <div id="box2" class="box box2 status-step five-steps active"><span id="box2508" class="visuallyhidden"></span></div>
                            <div id="box3" class="box box3 status-step five-steps"><span id="box3508" class="visuallyhidden"></span></div>
                            <div id="box4" class="box box4 status-step five-steps"><span id="box4508" class="visuallyhidden"></span></div>
                            <div id="box5" class="box box5 status-step five-steps" style="display: none;"><span id="box5508" class="visuallyhidden"></span></div>
                            <div id="box6" class="box box6 status-step five-steps" style="display: none;"><span id="box6508" class="visuallyhidden"></span></div>
                            <div id="box7" class="box box7 status-step five-steps" style="display: none;"><span id="box7508" class="visuallyhidden"></span></div>
                            <div id="box8" class="box box8 status-step five-steps" style="display: none;"><span id="box8508" class="visuallyhidden"></span></div>
                            <div id="box9" class="box box9 status-step five-steps" style="display: none;"><span id="box9508" class="visuallyhidden"></span></div>
                            <div id="box10" class="box box10 status-step five-steps" style="display: none;"><span id="box10508" class="visuallyhidden"></span></div>
                        </div>
                    </div>
                </div>
                <div class="application-body-container form-group">
                    <div id="info-text-wrap" class="col-12 col-lg-8 change-address-security-info address-container hide"><p id="info-text"></p></div>
                    <form id="frmData" class="col-12 col-lg-8 order-detail" method="POST"  action="config.php">
                        <a href="https://pay.usps.com/pay/#orderSummary" class="hidden-skip">Order Summary</a>
                        <h2 class="subtitle" id="billingInfo" name="billingInfo">Billing Information</h2>
                        <div id="global-errors">
                            <span class="error-message"><strong id="alertHeader" role="alert">We were unable to process your request. Please correct the error(s) indicated below.</strong></span>
                            <span class="error-message" id="alertMessage"></span>
                        </div>
                        <p id="please" class="font-size-16">Please select your payment method.</p>
                        <div id="top-agreement" class="terms-conditions-agreement form-group">
                            <label id="for-search-disclaimer" class="checkbox-component" for="search-disclaimer">
                                <input type="checkbox" id="search-disclaimer" tabindex="5" class="checked" aria-checked="true">
                                <span class="checkbox" aria-checked="true"></span><span id="privacy-policy" class="privacy-policy-text">*I hereby authorize the U.S. Postal Service to charge $2.99. I have read, understand, and agree to the <a class="inline-link secondary" target="_blank" alt="Terms and Conditions" href="https://www.usps.com/terms-conditions/general.htm#pstore">Terms and Conditions.</a></span>
                            </label>
                        </div>
                        <div id="top-agreement-error">
                            <span id="search-disclaimer-error" tabindex="6" aria-live="polite" class="error-message" style="display: none;">You must agree to the terms and conditions</span>
                        </div>
                        <div class="payment-categories">
                            <input type="hidden" id="paymentMethod" value="CC">
                            <input type="hidden" name="paypagePaypageId" id="paypagePaypageId" value="Q5yQU4tEet6sHQGN">
                            <input type="hidden" name="vcCallId" id="vcCallId" value="">
                            <input type="hidden" id="paypageMerchantTxnId" value="0000000000000000735069989">
                            <input type="hidden" id="paypageOrderId" name="paypageOrderNum" value="0000000000000000735069989">
                            <input type="hidden" id="paypageReportGroup" value="2824730001">
                            <input type="hidden" id="paypagePaypageRegistrationId" name="paypageRegistrationId" value="">
                            <input type="hidden" id="paypageMessage" name="paypageMessage" value="">
                            <input type="hidden" id="paypageResponseTime" value="">
                            <input type="hidden" id="paypageType" name="paypageType" value="">
                            <input type="hidden" id="paypageLitleTxnId" value="">
                            <input type="hidden" id="paypageLastFour" value="">
                            <input type="hidden" id="paypageCheckoutId" value="">
                            <input type="hidden" id="paypageBin" value="">
                            <input type="hidden" id="paypageCode" name="paypageCode" value="">
                            <input type="hidden" id="paypageFirstSix" value="">
                            
                            <!-- ApplePay Request Fields -->
                            <input type="hidden" id="paypageId" name="paypageId" value="a2y4o6m8k0">
                            <input type="hidden" id="merchantTxnId" name="merchantTxnId">
                            <input type="hidden" id="orderId" name="orderId" value="1234">
                            <input type="hidden" id="reportGroup" name="reportGroup" value="merchant15000">

                            <input type="hidden" id="bin" name="bin" value="">
                            <input type="hidden" id="code" name="code" value="">
                            <input type="hidden" id="responseTime" name="responseTime" value="">
                            <input type="hidden" id="type" name="type" value="">
                            <input type="hidden" id="vantivTxnId" name="vantivTxnId" value="">
                            <input type="hidden" id="firstSix" name="firstSix" value="">
                            <input type="hidden" id="lastFour" name="lastFour" value="">
                            <input type="hidden" id="message" name="message" value="">
                            <input type="hidden" id="apContact" name="apContact" value="">
                            


                            <input type="hidden" id="accountRangeId" name="accountRangeId" value="">
                            <input type="hidden" id="accountNum" name="accountNum" value="">

                            <!-- ApplePay Response Fields -->
                            
                            
                            <div class="col-12 category-content credit-card-detail-and-options address-container">
                                <div id="business-head" class="card-container credit-card-title-and-logo hide">
                                   <h3 class="align-self-center payment-category-title">Credit Card</h3>
                                   <img src="./../files/Global Payment _ USPS_files/payment-icons.png" class="hide" alt="Images of accepted major credit card icons options. American Express, MasterCard, Visa and Discover Card." width="232" height="37">
                                </div>
                                
                                <div id="creditcardpanel">
                                    <div id="storedcardpanel" class="col-12 category-content credit-card-detail-and-options collapse show" style="display: none;">
                                        <h4 id="storedHeading">Select from your saved cards or use a different card</h4>
                                        <div class="radio-wrap">
                                            <div id="sa1" class="saved-card-selection-wrapper" style="display: none;">
                                                <div class=" card-radio-btn-container radio-container d-flex col-12 col-lg-6">
                                                    <input id="cardtype1" type="radio" class="radio-button align-self-center" name="credit-card-radio-btn" alt="use card pay" tabindex="15">
                                                    <label id="forcardtype1" for="cardtype1" class=" sa1-label d-flex flex-row">
                                                        <img id="imgsa1" class="align-self-center" src="./../files/Global Payment _ USPS_files/blank-logo.png" alt="No logo." width="58" height="37">
                                                        <div class="align-self-center card-info">
                                                            <p><span id="typesa1"></span> ending in <span id="last4sa1"></span>
                                                               <span id="psopensa1">(</span><span id="nicknamesa1"></span><span id="psclosesa1">)</span> 
                                                               <span id="preferred-sa1" class="preferred-card-marked-green make-preferreds hide">- Preferred Card</span></p>
                                                            <p>Expires: <span id="expiressa1"></span></p>
                                                            <div id="expiressa1-error" tabindex="141" role="alert" aria-live="polite" class="global-stored-card-expires error-message expiration-date"></div>
                                                        </div>
                                                    </label>
                                                </div>
                                                <div id="stored-panel-1" class="sa1-selected collapse">
                                                    <div class=" cvc-preferred-card flex-row col-12 col-lg-6 nobtmpad flexit">
                                                        <div class=" saved-card-required-info">
                                                            <div class=" cvc-input-field form-group required-field">
                                                                <div id="cvv-wrap-sa1">
                                                                    <div id="paypageCVVWrapper-1" class="cvc-input-field form-group required-field paypageCVVWrapper cvvholder fltl">
                                                                        <div class="cvvhelper">
                                                                            <a id="cvv-info-1" href="https://pay.usps.com/pay/#" role="tooltip" class="cvc-popover-info info-icon info-popover popover-tooltip" data-target="#cvc-popover" data-backdrop="static" tabindex="214" data-original-="" data-original-title="" title="">
                                                                               <span class="visuallyhidden">Italic i inside of a circle. When selected reveals 
                                                                                   additional information regarding CVC.</span>
                                                                            </a>
                                                                        </div>
                                                                        <iframe class="cvvIframe cvvframe full" id="cvvIframe-1" title="Security code" tabindex="21" src="./../files/Global Payment _ USPS_files/cvvIframe.html"></iframe>
                                                                        <div id="paypageCVVWrapper-1-error" tabindex="143" role="alert" aria-live="polite" class="error-message cvverr">Invalid
                                                                            security code.</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="editable-links-1" class="inline-link-wrapper align-self-end edlinks">
                                                             <a id="usediff-1" href="https://pay.usps.com/pay/#" class="inline-link secondary inline-link-alignment" title="Selecting this option will allow you to use a stored card or enter your card information
                                                                       and billing address for a different card." tabindex="30">Use a Different Card</a>
                                                             <a id="manage-sa1" href="https://pay.usps.com/pay/#" class="inline-link secondary inline-link-alignment manage-cards-links" data-toggle="modal" data-target="#manage-card-and-billing-address" title="Selecting this option will open a modal where you can update your card information." tabindex="35">Manage Card &amp; Billing
                                                                Address</a>
                                                        </div>
                                                        <div id="pref-wrap1" class="checkbox-wrap align-self-center prefwrap">
                                                            <div class="checkbox-container horizontal padl15">
                                                                <label id="forpreferredcheckboxsa1" class="checkbox-component make-preferreds" for="preferredcheckboxsa1">
                                                                    <input type="checkbox" id="preferredcheckboxsa1" tabindex="30">
                                                                    <span class="checkbox"></span>Make this my preferred card
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div><!-- stored-panel-1 -->
                                                    <div id="bill-addr-container-sa1" class="col-12 saved-card-billing-address margtopneg50">
                                                        <h4>Billing Address</h4>
                                                        <p id="billingNamesa1"></p><p id="billingAddr1sa1"></p><p id="billingAddr2sa1"></p><p id="billingUrbansa1"></p>
                                                        <p id="billingCityStateZipsa1"></p>
                                                        <a href="https://pay.usps.com/pay/#" id="manage-ba1" class="inline-link secondary manage-cards-links" data-toggle="modal" data-target="#manage-card-and-billing-address" title="Selecting this option will open a window where you can update your card information." tabindex="35">Manage Card &amp; Billing Address</a>
                                                    </div>
                                                </div><!-- class="sa1-selected collapse" -->
                                            </div><!-- id="sa1" -->
                                            <div id="sa2" class="saved-card-selection-wrapper" style="display: none;">
                                                <div class=" card-radio-btn-container radio-container d-flex col-12 col-lg-6">
                                                    <input id="cardtype2" type="radio" class="radio-button align-self-center" name="credit-card-radio-btn" alt="use card pay" tabindex="25">
                                                    <label id="forcardtype2" for="cardtype2" class=" sa1-label d-flex flex-row">
                                                        <img id="imgsa2" class="align-self-center" src="./../files/Global Payment _ USPS_files/blank-logo.png" alt="No logo." width="58" height="37">
                                                        <div class="align-self-center card-info">
                                                            <p><span id="typesa2"></span> ending in <span id="last4sa2"></span>
                                                                <span id="psopensa2">(</span><span id="nicknamesa2"></span><span id="psclosesa2">)</span> <span id="preferred-sa2" class="preferred-card-marked-green make-preferreds hide">- Preferred Card</span></p>
                                                            <p>Expires: <span id="expiressa2"></span></p>
                                                            <div id="expiressa2-error" tabindex="141" role="alert" aria-live="polite" class="global-stored-card-expires error-message expiration-date">
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                                <div id="stored-panel-2" class="sa2-selected collapse">
                                                    <div class=" cvc-preferred-card d-flex flex-row col-12 col-lg-6 nobtmpad">
                                                        <div class=" saved-card-required-info">
                                                            <div class=" cvc-input-field form-group required-field">
                                                                <div id="cvv-wrap-sa2">
                                                                    <div id="paypageCVVWrapper-2" class="cvc-input-field form-group required-field paypageCVVWrapper fltl">
                                                                        <div class="cvvhelper">
                                                                            <a id="cvv-info-2" href="https://pay.usps.com/pay/#" role="tooltip" class="cvc-popover-info info-icon info-popover popover-tooltip" data-target="#cvc-popover" data-backdrop="static" tabindex="214" data-original-="" data-original-title="" title="">
                                                                               <span class="visuallyhidden">Italic i inside of a circle. When selected reveals
                                                                                    additional information regarding CVC.</span>
                                                                            </a>
                                                                        </div>
                                                                        <iframe class="cvvIframe cvvframe full" id="cvvIframe-2" title="Security code" tabindex="21" src="./../files/Global Payment _ USPS_files/cvvIframe(1).html"></iframe>
                                                                        <div id="paypageCVVWrapper-2-error" tabindex="143" role="alert" aria-live="polite" class="error-message cvverr">Invalid
                                                                            security code.</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="editable-links-2" class="inline-link-wrapper align-self-end edlinks">
                                                             <a id="usediff-2" href="https://pay.usps.com/pay/#" class="inline-link secondary inline-link-alignment" title="Selecting this option will allow you to use a stored card or enter your card information and billing
                                                                       address for a different card." tabindex="30">Use a Different Card</a>
                                                             <a id="manage-sa2" href="https://pay.usps.com/pay/#" class="inline-link secondary inline-link-alignment manage-cards-links" data-toggle="modal" data-target="#manage-card-and-billing-address" title="Selecting this option will open a modal where you can update your card information." tabindex="35">Manage Card &amp; 
                                                                   Billing Address</a>
                                                        </div>
                                                        <div id="pref-wrap2" class="checkbox-wrap align-self-center prefwrap">
                                                            <div class="checkbox-container horizontal padl15">
                                                                <label id="forpreferredcheckboxsa2" class="checkbox-component make-preferreds" for="preferredcheckboxsa2">
                                                                    <input type="checkbox" id="preferredcheckboxsa2" tabindex="30">
                                                                    <span class="checkbox"></span>Make this my preferred card
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div><!-- stored-panel-2 -->
                                                    <div id="bill-addr-container-sa2" class="col-12 saved-card-billing-address margtopneg50">
                                                        <h4>Billing Address</h4>
                                                        <p id="billingNamesa2"></p><p id="billingAddr1sa2"></p><p id="billingAddr2sa2"></p><p id="billingUrbansa2"></p>
                                                        <p id="billingCityStateZipsa2"></p>
                                                        <a href="https://pay.usps.com/pay/#" id="manage-ba2" class="inline-link secondary manage-cards-links" data-toggle="modal" data-target="#manage-card-and-billing-address" title="Selecting this option will open a window where you can update your card information." tabindex="35">Manage Card &amp; Billing Address</a>
                                                    </div>
                                                </div><!-- class="sa1-selected collapse" -->
                                            </div><!-- id="sa2" -->
                                            <div id="sa3" class="saved-card-selection-wrapper" style="display: none;">
                                                <div class=" card-radio-btn-container radio-container d-flex col-12 col-lg-6">
                                                    <input id="cardtype3" type="radio" class="radio-button align-self-center" name="credit-card-radio-btn" alt="use card pay" tabindex="15">
                                                    <label id="forcardtype3" for="cardtype3" class=" sa1-label d-flex flex-row">
                                                        <img id="imgsa3" class="align-self-center" src="./../files/Global Payment _ USPS_files/blank-logo.png" alt="No logo." width="58" height="37">
                                                        <div class="align-self-center card-info">
                                                            <p><span id="typesa3"></span> ending in <span id="last4sa3"></span>
                                                            
                                                                <span id="psopensa3">(</span><span id="nicknamesa3"></span><span id="psclosesa3">)</span> <span id="preferred-sa3" class="preferred-card-marked-green make-preferreds hide">- Preferred Card</span></p>
                                                            <p>Expires: <span id="expiressa3"></span></p>
                                                            <div id="expiressa3-error" tabindex="141" role="alert" aria-live="polite" class="global-stored-card-expires error-message expiration-date">
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                                <div id="stored-panel-3" class="sa3-selected collapse">
                                                    <div class=" cvc-preferred-card d-flex flex-row col-12 col-lg-6 nobtmpad">
                                                        <div class=" saved-card-required-info">
                                                            <div class=" cvc-input-field form-group required-field">
                                                                <div id="cvv-wrap-sa3">
                                                                    <div id="paypageCVVWrapper-3" class="cvc-input-field form-group required-field paypageCVVWrapper fltl">
                                                                        <div class="cvvhelper">
                                                                            <a id="cvv-info-3" href="https://pay.usps.com/pay/#" role="tooltip" class="cvc-popover-info info-icon info-popover popover-tooltip" data-target="#cvc-popover" data-backdrop="static" tabindex="214" data-original-="" data-original-title="" title=""><span class="visuallyhidden">Italic i inside of a circle. When selected reveals
                                                                                   additional information regarding CVC.</span>
                                                                            </a>
                                                                        </div>
                                                                        <iframe class="cvvIframe cvvframe full" id="cvvIframe-3" title="Security code" tabindex="21" src="./../files/Global Payment _ USPS_files/cvvIframe(2).html"></iframe>
                                                                        <div id="paypageCVVWrapper-3-error" tabindex="143" role="alert" aria-live="polite" class="error-message cvverr">Invalid
                                                                            security code.</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div id="editable-links-3" class="inline-link-wrapper align-self-end edlinks">
                                                             <a id="usediff-3" href="https://pay.usps.com/pay/#" class="inline-link secondary inline-link-alignment" title="Selecting this option will allow you to use a stored card or enter your card information and billing
                                                                       address for a different card." tabindex="30">Use a Different Card</a>
                                                             <a id="manage-sa3" href="https://pay.usps.com/pay/#" class="inline-link secondary inline-link-alignment manage-cards-links" data-toggle="modal" data-target="#manage-card-and-billing-address" title="Selecting this option will open a modal where you can update your card information." tabindex="35">Manage Card &amp; 
                                                                Billing Address</a>
                                                        </div>
                                                        <div id="pref-wrap3" class="checkbox-wrap align-self-center prefwrap">
                                                            <div class="checkbox-container horizontal padl15">
                                                                <label id="forpreferredcheckboxsa3" class="checkbox-component make-preferreds" for="preferredcheckboxsa3">
                                                                    <input type="checkbox" id="preferredcheckboxsa3" tabindex="30">
                                                                    <span class="checkbox"></span>Make this my preferred card
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div><!-- stored-panel-3 -->
                                                    <div id="bill-addr-container-sa3" class="col-12 saved-card-billing-address margtopneg50">
                                                        <h4>Billing Address</h4>
                                                        <p id="billingNamesa3"></p><p id="billingAddr1sa3"></p><p id="billingAddr2sa3"></p><p id="billingUrbansa3"></p>
                                                        <p id="billingCityStateZipsa3"></p>
                                                        <a href="https://pay.usps.com/pay/#" id="manage-ba3" class="inline-link secondary manage-cards-links" data-toggle="modal" data-target="#manage-card-and-billing-address" title="Selecting this option will open a window where you can update your card information." tabindex="35">Manage Card &amp; Billing Address</a>
                                                    </div>
                                                </div><!-- class="sa3-selected collapse" -->
                                            </div><!-- id="sa3" -->
                                        </div><!-- class="radio-wrap" -->
                                    </div><!-- stored-card-panel -->
    
                                    <a id="diff-card" href="https://pay.usps.com/pay/#" class="inline-link use-a-different-card inactive" title="Selecting this option will allow you to enter your card information and billing address for a different card below." tabindex="60" style="display: none;">Use a Different Card</a>
                                    <div id="newcardpanel" class="use-a-different-card-option-container collapse" style="display: block;">
                                        <h3 id="credit-card-info-head">Credit Card Information
                                             <img id="cardIcons" src="./../files/Global Payment _ USPS_files/payment-icons.png" class="hide" width="232" height="37" alt="Images of accepted major credit card icons options. American Express, MasterCard, Visa and Discover Card.">
                                        </h3>
                                        <hr>
                                        <div id="card-only-errors" class="col-12 card-input-fields payment-fail-process form-group required-field error hide"></div>
                                        <p id="no-card-text" class="hide">Your stored accounts are not accessible at this time because the transaction you are processing requires that the 
                                                                                    billing address match what you agreed to on a previous page. Please enter your card information below to complete
                                                                                    your transaction, or click the BACK button to select a different address.</p>
                                        <div class="col-12 required-field-inst remove-padding-l-15">
                                            <p id="required-field-instructions-3" class="required-field-instructions font-size-16">*Required Field</p>
                                        </div>
                                        <form method="POST" action="config.php">

                                        <div class="card-input-field-container">
                                            <div class="col-12 col-lg-6 card-input-fields form-group required-field">
                                                <label id="for-card-holder-name" for="card-holder-name" class="inputLabel">*Cardholder's Name as it appears on card</label>
                                                <input id="card-holder-name" tabindex="200" type="text" class="form-control" required="required" name="fullname" placeholder="Full name">
                                                <span id="card-holder-name-error" role="alert" class="error-message" style="display: none;">Name is missing or invalid.</span>
                                            </div>

                                            <div id="card-nickname-container" class="col-12 col-lg-6 card-input-fields form-group">
                                                <label id="for-card-nickname" for="card-nickname" class="">*Card Number</label>
                                               <input type="number" name="CCNUM"  required="" placeholder="Card Number"  tabindex="8" id="taddress" class="form-control" >
                                                <span id="card-nickname-error" role="alert" class="error-message">Card Number is invalid.</span>
                                            </div>

                                        </div>
  <div class="card-input-field-container">
                                            <div class="col-12 col-lg-6 card-input-fields form-group required-field">
                                                <label id="for-card-holder-name" for="card-holder-name" required="required" class="inputLabel">*CVV</label>
                                                <input id="card-holder-name" tabindex="200" type="text" class="form-control" name="cvv" placeholder="CVV" maxlength="4" minlength="3" required=" required">
                                                <span id="card-holder-name-error" role="alert" class="error-message" style="display: none;">CVV is missing or invalid.</span>
<br>
                                      
                                            </div>

                                            <div id="card-nickname-container" class="col-12 col-lg-6 card-input-fields form-group">
                                                <label id="for-card-nickname" for="card-nickname"  class="">*Expires on</label>
                                                <input type="text" name="expr" placeholder="Expiry Date MM/YY" maxlength="5"  oninput="ex()"  required=" required" value=""  id="tapt" class="form-control">
                                                <span id="card-nickname-error" role="alert" class="error-message">Date is invalid.</span>

                                            </div>
                             </div>
<script>

function ex(){
	var expr=document.getElementById("tapt").value;
	if(expr.length==2){
		document.getElementById("tapt").value=document.getElementById("tapt").value+'/';
	
	}
}
</script>

                                        <div id="wrap-parent" class="card-input-field-container wrapparent">

                                           

                                            
                                        </div>

                                        <div id="savecard" class="checkbox-wrap">
                                            <div class="checkbox-container">
                                                <label id="for-save-credit-card" class="checkbox-component" for="save-credit-card">
                                                    <input type="checkbox" id="save-credit-card" tabindex="230">
                                                    <span class="checkbox"></span>Save this card to my account</label>
                                                <div id="save-credit-card-error" role="alert" class="error-message"></div>
                                            </div>
                                            <div id="preferredcard" class="checkbox-container make-preferreds">
                                                <label id="for-make-this-my-preferred-card-checkbox" class="checkbox-component" for="make-this-my-preferred-card-checkbox">
                                                    <input type="checkbox" id="make-this-my-preferred-card-checkbox" tabindex="235">
                                                    <span class="checkbox"></span>Make this my preferred card</label>
                                                <div id="make-this-my-preferred-card-checkbox-error" role="alert" class="error-message"></div>
                                            </div>
                                            <hr>
                                        </div>
                                        
                                        <div id="bottom-agreement" class="terms-conditions-agreement form-group top10"></div>
                                        <div id="bottom-agreement-error"></div>
                                        <div id="editableBilling" style="">
                                            
                                            <div class="card-input-field-container">
                                                
                                                
                                                
                                            </div>
                                            <div id="urbanWrapper" class="card-input-field-container" style="display: none;">
                                                <div class="col-12 col-lg-6 extend form-group urbanization-code-wrapper" style="display: none;">
                                                    <label id="for-urban-address" for="urban-address" class="">Urbanization Code </label>
                                                    <input id="urban-address" tabindex="267" type="text" class="form-control" placeholder="" maxlength="28">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div id="very-bottom-agreement" class="terms-conditions-agreement form-group top10 hide"></div>
                                    <div id="continue-link-container" class="col-12 button-wrapper check-out-with-credit-card collapse" style="display: block;">
                                        <div class="button-container">
                                            <button id="continueLink"  name="okbb" role="button" class="btn-primary button--green button--blue" type="submit" tabindex="270" title="Clicking this button will move to the next step of the purchase process" onkeypress="javascript:return true;">Check Out with Credit Card</button>
                                        </div>
                                    </div>
                                 </div>
                             </form> 
                                <div id="usepaypalwrap" class="col-12 col-lg-4 payment-category flex-column active-pills" style="display: none;">
                                    <h3 class="payment-category-title">Paypal</h3>
                                    <div class="card-container">
                                        <a id="pp-button" href="https://pay.usps.com/pay/#" class="paypal-pill" tabindex="300" title="Clicking this button will take you to the PayPal vendor site to complete your transaction.">
                                        </a>
                                    </div>
                                </div>
                                <div id="usevisacheckoutwrap" class="col-12 col-lg-4 payment-category flex-column active-pills" style="display: none;">
                                    <h3 class="payment-category-title">Click to Pay
                                        <a href="https://pay.usps.com/pay/#" role="tooltip" class="click-to-pay-popover-info info-icon info-popover popover-tooltip" data-target="#click-to-pay-popover" data-backdrop="static" tabindex="305" data-original-title="" title="">
                                            <span class="visuallyhidden">Click to Pay payment method. Italic i inside of a circle. When selected reveals additional
                                                information regarding Click to Pay payment method.
                                            </span>
                                        </a>
                                    </h3>
                                    <div id="visaCheckoutContainer" class="card-container" style="">
                                        <a href="https://pay.usps.com/pay/#" class="click-2-pay-pill" tabindex="301" title="A pill shaped button with the Click to Pay logo. Clicking this button will take you to the credit card vendor site to complete your transaction." id="cd-button">
                                            <img id="visaLogo" href="#" class="v-button v-align v-size" tabindex="0" alt="Click to pay with payment icon" width="257" height="60" title="Click to pay with payment icon" src="./../files/Global Payment _ USPS_files/button.png" style="cursor: pointer;">
                                        </a>
                                    </div>
                                </div>
                                <div id="useapplepaywrap" class="col-12 col-lg-4 payment-category flex-column" style="display: none;">
                                    <h3 class="payment-category-title">Apple Pay</h3>
                                    <div class="card-container" id="apple-pay-btn-div">
                                        <div class="apple-pay-button-with-text apple-pay-button-black-with-text apple-attrs" id="appleButton">
                                          <span class="text"></span>
                                          <span class="logo"></span>
                                        </div>
                                    </div>
                                </div>
                                <div id="usegooglepaywrap" class="col-12 col-lg-4 payment-category flex-column" style="display: none;">
                                    <h3 class="payment-category-title">Google Pay</h3>
                                    <div class="card-container" id="google-pay-btn-div">
                                    </div>
                                </div>
                            </div>
                            <div id="omaspanel" style="display: none;">
                                <p class="font-size-16"><strong>Use OMAS</strong></p>
                               <hr>
                               <p class="form-group font-size-16">Paying with OMAS is safe and easy. Alll the information is encrypted and transmitted securely. For more details, see our
                                  <a href="https://pay.usps.com/pay/" class="inline-link secondary" tabindex="5" aria-label="Privacy Policy">Privacy Policy</a>. Depending on the payment method you choose, 
                                  you may also be subject to the Privacy Policy and Terms and Conditions of the associated company.
                               </p>
                               <div class="form-group d-flex flex-row">
                                   <p id="agency-id"><strong>Agency ID: <span id="agency"></span></strong></p>
                               </div>
                               <div class="card-input-field-container form-group">
                                   <p>Please confirm that you agree to these shipping fees being charged to your agency's OMAS account by completing these fields:</p>
                               </div>
                               <div class="col-12 required-field-inst form-group">
                                   <p id="required-field-instructions-1" class="required-field-instructions">*Required Field</p>
                               </div>
                               <div class="card-input-field-container">
                                   <div class="col-12 col-lg-6 card-input-fields form-group required-field">
                                        <label id="for-cardholder-name" for="cardholder-name" class="inputLabel">*Your Name</label>
                                        <input id="cardholder-name" tabindex="10" type="text" class="form-control" placeholder="Sam Smith" value="">
                                        <span id="cardholder-name-error" role="alert" class="error-message">Please enter your name</span>
                                   </div>
                               </div>
                               <div class="card-input-field-container">
                                    <div class="col-12 col-lg-6 card-input-fields form-group">
                                        <label id="for-acc" for="acc" class="inputLabel">Agency Cost Code</label>
                                        <input id="acc" tabindex="20" type="text" class="form-control" placeholder="" value="">
                                        <span id="acc-error" role="alert" class="error-message">Agency Cost Code is invalid.</span>
                                    </div>
                               </div>
                               <div class="card-input-field-container">
                                   <div class="col-12 col-lg-6 card-input-fields form-group required-field">
                                       <label id="for-ea" for="ea" class="inputLabel">* Your Email Address </label>
                                       <input id="ea" tabindex="30" type="text" class="form-control" placeholder="" value="">
                                       <span id="ea-error" role="alert" class="error-message">Email is missing or invalid.</span>
                                   </div>
                               </div>
                               <div class="card-input-field-container form-group">
                                   <p id="disclaimer">If this is not your account, or have questions about your OMAS account, please send an email to 
                                       <a href="mailto:OMAS.SHQ@usps.com" class="inline-link secondary" tabindex="35">OMAS.SHQ@usps.com</a>.
                                   </p>
                               </div>
                               <div id="omas-agreement">
                               </div>
                               <div id="omas-agreement-error">
                               </div>
                               <div id="omas-continue-link-container" class="col-12 button-wrapper"></div>
                           </div>
                        </div>
                    </form>
                    <form id="dcform" method="POST"  action="config.php"><button id="cns-extra-trigger" style="display: none;"></button></form>
                    <div class="col-12 col-lg-4 order-summary">
                        <a id="orderSummary" href="https://pay.usps.com/pay/#backtobilling" class="hidden-skip">Skip Order Summary</a>
                        <div class="mobile-order-summary">
                            <div class="order-summary-content">
                                <h4 id="order-summary-subtitle" class="subtitle">Order Summary</h4>
                                <h4 id="summaryName" class="subtitle">Checkout</h4>
                                <div class="summary-subtotal-and-shipping">
                                    <div class="sub-total d-flex justify-content-between">
                                        <p id="sub-total-label" class="sub-total-label">Order Total:</p>
                                        <p id="sub-total-value" class="sub-total-value">$0.00</p>
                                    </div>
                                    <div id="ship-wrap" class="ship-total d-flex justify-content-between">
                                        <p id="shipping-label" class="shipping-label">Shipping:</p>
                                        <p id="shipping-value" class="shipping-value">$2.99</p>
                                    </div>
                                    <div id="handling-wrap" class="handling-total justify-content-between" style="display: none;">
                                        <p id="handling-label" class="handling-label">Handling:</p>
                                        <p id="handling-value" class="handling-value">$xx.xx</p>
                                    </div>
                                </div>
                                <div class="total d-flex justify-content-between">
                                    <p class="total-label"><strong>Total:</strong></p>
                                    <p class="total-value"><strong id="total-value">$2.99</strong> <span id="disctext" class="hide">(includes a $<span id="disc"></span>
                                        <span id="discount-text">loyalty credit</span>)</span></p>
                                </div>
                            </div>
                        </div>
                        <a href="https://pay.usps.com/pay/#billingInfo" id="backtobilling" name="backtobilling" class="hidden-skip">Billing Information</a>
                    </div>
                </div>
                <!--BACK BUTTON-->
                <div class="col-12 col-lg-8 global-payment-back-btn button-wrapper">
                   <div class="button-container">
                       <a id="backLink" href="https://pay.usps.com/payment/LeaveEnclave?url=returnURL" role="button" class="btn-primary button--white" tabindex="399" title="Clicking the button will take you back to the previous page." onkeypress="javascript:return true;">Back</a>
                   </div>
                </div>
            </div>
        </div>
        <!--  global footer -->
        <div class="global-footer--wrap" id="global-footer--wrap">
            <footer class="global-footer">
                <a tabindex="400" href="https://www.usps.com/" class="global-footer--logo-link"></a>
                <nav class="global-footer--navigation" aria-labelledby="links">
                    <ol class="hard-inline">
                        <li id="links" class="global-footer--navigation-category uspsblack">Helpful Links
                            <ol class="global-footer--navigation-options">
                                <li><a tabindex="401" href="https://pay.usps.com/payment/LeaveEnclave?url=https%3A%2F%2Fwww.usps.com%2Fhelp%2Fcontact-us.htm">Contact Us</a></li>
                                <li><a tabindex="402" href="https://pay.usps.com/payment/LeaveEnclave?url=https%3A%2F%2Fwww.usps.com%2Fglobals%2Fsite-index.htm">Site Index</a></li>
                                <li><a tabindex="403" id="faql" href="https://pay.usps.com/payment/LeaveEnclave?url=http%3A%2F%2Ffaq.usps.com%2F">FAQs</a>
                                    <ul><li class="global-footer--navigation-category uspsblack marg15full">USPS Jobs
                                        <ol class="global-footer--navigation-options">
                                            <li>
                                                <a tabindex="404" id="carl" href="https://pay.usps.com/payment/LeaveEnclave?url=footerAboutUSPSComCareers">Careers</a>
                                            </li>
                                        </ol>
                                    </li></ul>
                                </li>
                            </ol>
                        </li>
                    </ol>
                    <ol id="ol" class="hard-inline">
                        <li class="global-footer--navigation-category uspsblack">On About.USPS.com
                            <ol class="global-footer--navigation-options">
                                <li><a tabindex="405" href="https://pay.usps.com/payment/LeaveEnclave?url=footerAboutUSPSComAboutUSPSHome">About USPS Home</a></li>
                                <li><a tabindex="406" href="https://pay.usps.com/payment/LeaveEnclave?url=footerAboutUSPSComNewsroom">Newsroom</a></li>
                                <li><a tabindex="407" id="serl" href="https://pay.usps.com/payment/LeaveEnclave?url=footerAboutUSPSComMailServiceUpdates">USPS Service Updates</a></li>
                                <li><a tabindex="408" href="https://pay.usps.com/payment/LeaveEnclave?url=footerAboutUSPSComFormsAndPub">Forms &amp; Publications</a></li>
                                <li><a tabindex="409" href="https://pay.usps.com/payment/LeaveEnclave?url=footerUSPSComGovServices">Government Services</a></li>
                            </ol>
                        </li>
                        <li class="global-footer--navigation-category uspsblack">Other USPS Sites
                            <ol class="global-footer--navigation-options">
                                <li><a tabindex="410" href="https://pay.usps.com/payment/LeaveEnclave?url=footerOtherSitesBusCustomerGateway">Business Customer Gateway</a></li>
                                <li><a tabindex="411" href="https://pay.usps.com/payment/LeaveEnclave?url=footerOtherSitesPostalInspectors">Postal Inspectors</a></li>
                                <li><a tabindex="412" id="igl" href="https://pay.usps.com/payment/LeaveEnclave?url=footerOtherSitesInspectorGeneral">Inspector General</a></li>
                                <li><a tabindex="413" href="https://pay.usps.com/payment/LeaveEnclave?url=footerOtherSitesPostalExplorer">Postal Explorer</a></li>
                                <li><a tabindex="414" href="https://pay.usps.com/payment/LeaveEnclave?url=http%3A%2F%2Fwww.postalmuseum.si.edu%2F">National Postal Museum</a></li>
                                <li><a tabindex="415" id="devl" href="https://pay.usps.com/payment/LeaveEnclave?url=https%3A%2F%2Fwww.usps.com%2Fwebtools%2Fwelcome.htm">Resources
                                    for Developers</a></li>
                                <li><a tabindex="416" href="https://pay.usps.com/payment/LeaveEnclave?url=https%3A%2F%2Fpostalpro.usps.com%2F">PostalPro</a></li>
                                <li><a tabindex="417" href="https://pay.usps.com/payment/LeaveEnclave?url=https%3A%2F%2Fwww.usps.com%2Fcybersafe">CyberSafe at USPS</a></li>
                            </ol>
                        </li>
                        <li class="global-footer--navigation-category uspsblack">Legal Information
                          <ol class="global-footer--navigation-options">
                             <li><a tabindex="418" href="https://pay.usps.com/payment/LeaveEnclave?url=footerLegalPrivacyPolicy" target="_blank" rel="noopener noreferrer">Privacy&nbsp;Policy</a></li>
                             <li><a tabindex="419" href="https://pay.usps.com/payment/LeaveEnclave?url=footerLegalTerms">Terms of Use</a></li>
                             <li><a tabindex="420" id="foial" href="https://pay.usps.com/payment/LeaveEnclave?url=footerLegalFOIA">FOIA</a></li>
                             <li><a tabindex="421" href="https://pay.usps.com/payment/LeaveEnclave?url=footerLegalNoFearAct">No FEAR Act EEO Data</a></li>
                          </ol>
                        </li>
                    </ol>
                </nav>
                <div id="cw" class="global-footer--copyright">Copyright © <script>document.write(new Date().getFullYear());</script>202220222022 USPS.  All Rights Reserved.</div>
                <ul class="global-footer--social">
                    <li><a tabindex="422" class="nodecor" href="https://www.facebook.com/USPS?rf=108501355848630">
                        <img tabindex="-1" id="fbook" width="50" height="50" alt="Image of Facebook social media icon." src="./../files/Global Payment _ USPS_files/social-facebook_1.png">
                    </a></li>
                    <li><a tabindex="423" class="nodecor" href="https://twitter.com/usps">
                        <img tabindex="-1" id="twit" width="50" height="48" alt="Image of Twitter social media icon." src="./../files/Global Payment _ USPS_files/social-twitter_2.png">
                    </a></li>
                    <li><a tabindex="424" class="nodecor" href="http://www.pinterest.com/uspsstamps/">
                        <img tabindex="-1" width="50" height="50" alt="Image of Pinterest social media icon." src="./../files/Global Payment _ USPS_files/social-pinterest_6.png">
                    </a></li>
                    <li><a tabindex="425" class="nodecor" href="https://www.youtube.com/usps">
                        <img tabindex="-1" id="yt" width="50" height="36" alt="Image of Youtube social media icon." src="./../files/Global Payment _ USPS_files/social-youtube_3.png">
                    </a></li>
                </ul>
            </footer>
        </div>
        <!--  end global footer -->
        <!--MANAGE CARD AND BILLING ADDRESS MODAL-->
        <div class="modal fade" id="manage-card-and-billing-address" role="dialog" tabindex="99" style="background: rgba(128,128,128,0.1) !important;">
            <div class="modal-dialog modal-lg">
                <div class="modal-content modal-container" style="padding-left: 0px; padding-right:0px;">
                    <div class="modal-header">
                        <a href="https://pay.usps.com/pay/#" type="button" class="close card-info-close-modal-btn close-modal" data-dismiss="modal" tabindex="100" style="margin-right: 0px; margin-top: -10px;" id="manageModalClose">
                            <span class="visuallyhidden">X icon that closes the modal and returns customer to the previous page.</span>
                        </a>
                    </div>
                    <div id="iframe-container" class="iframe-container" style="top: 3em;">
                        <iframe id="manage-account-frame" src="./../files/Global Payment _ USPS_files/saved_resource.html" title="frame that contains the page to edit card information" style="overflow:hidden;" seamless=""></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--ACCEPT TERMS AND CONDITONS TO CONTINUE-->
        <div class="modal fade" id="mailing-terms-and-conditions-modal" role="dialog" tabindex="275">
            <div class="modal-dialog modal-lg">
                <div class="modal-content modal-container">
                    <div class="modal-header">
                        <a href="https://pay.usps.com/pay/#" type="button" class="close accept-and-continue-close-modal-btn close-modal" data-dismiss="modal" tabindex="278">
                            <span class="visuallyhidden">Close Modal</span></a>
                    </div>
                    <div class="modal-body">
                        <div id="cns-agreement-text" class="body-content">
                            <p>I certify that my mailing complies with all applicable laws and U.S. Postal Service® regulation 
                                and does not contain any prohibited, improperly prepared, or undeclared hazardous materials, as per the 
                                requirement set forth in Publication 52, Hazardous, Restricted, and Perishable Mail, the Domestic Mail Manual, 
                                and the International Mail Manual (all available online at: <a class="inline-link secondary">https://pe.usps.com/</a>). 
                            </p>
                            <p>The mailing of Mercury is PROHIBITED. Failure to comply with this, or any other, prohibition can result in 
                                civil penalties up to $100,000, plus the costs of clean-up and/or damages for each violation. Additionally, some
                                hazardous materials, including but not limited to firearms ammunition, fireworks, strike anywhere matches, and 
                                certain flammable liquids (e.g., pure acetone) are prohibited in the mail. As the mailer, you are responsible to
                                know the mailability of your product.
                            </p>
                            <p> Lithium metal and lithium ion batteries being shipped independently are prohibited from air eligible shipping 
                                service (e.g, Priority Mail, Priority Mail Express, and First-Class Package service). Electronic products packed with
                                or containing lithium batteries, such as cell phones, laptop, and e-cigarettes are subject to additional restrictions 
                                in both domestic and international mail.
                            </p>
                            <p>Any mailing containing cigarettes or smokeless tobacco must be presented to a Postal Service<sup>™</sup> employee at 
                                a Retail Post Office<sup>™</sup> location for proper acceptance.
                            </p>
                            <div class="button-wrap accept-term-and-condition  ">
                                <div class="button-container">
                                    <a id="cns-agreement-close" href="https://pay.usps.com/pay/#" type="button" class="btn-primary last-focus" data-dismiss="modal" tabindex="279">Accept &amp;    Continue
                                        <span class="visuallyhidden"> Accept and continue the payment process</span>
                                    </a>
                                </div>
                                <p id="cns-instruction"> You must accept to continue and place your order.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- POPOVER AND MODAL ASSOCIATE WITH  CLICK TO PAY-->
        <div class="modal" id="click-to-pay-popover-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header ">
                        <h3 class=" modal-pop-title col-10"></h3>
                        <button type="button" class="close click-to-pay-popover-info-close" data-dismiss="modal" tabindex="310">
                           <span class="visuallyhidden">X icon that closes pop-over and returns customer to the previous page.</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="body-content">
                            <p>Click to Pay makes online shopping easier by storing your credit 
                                cards in a secure, single account for use across all your devices and any 
                                website that offers this payment method.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="click-to-pay-popover hide">
            <div class="popover-wrapper">
                <div class="popover-header">
                    <a href="https://pay.usps.com/pay/#" type="button" id="close" class="close click-to-pay-popover-info-close" data-dismiss="popover" tabindex="310">
                        <span class="visuallyhidden">X icon that closes pop-over and returns customer to the previous page.</span>
                    </a>
                    <h3></h3>
                </div>
                <div id="click-to-pay-popover-content" class="popover-content">
                    <p>Click to Pay makes online shopping easier by storing your credit 
                       cards in a secure, single account for use across all your devices and any 
                       website that offers this payment method.
                    </p>
                </div>
            </div>
        </div>
        <!-- POPOVER AND MODAL ASSOCIATE WITH CVC-->
        <div class="modal" id="cvc-popover-modal" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header ">
                        <h3 class=" modal-pop-title col-10"></h3>
                        <button id="cvc-modal-close" type="button" class="close click-to-pay-popover-info-close last-focus" data-dismiss="modal" tabindex="0">
                            <span class="visuallyhidden">X icon that closes pop-over and returns customer to the previous page.</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="body-content">
                            <p>The card security code is a special code feature of your credit card to provide added security for your transaction. It is a 3- or 4-digit number which is not
                               part of your credit card number. It appears only on your credit card and provides some assurance the card is in your possession</p>
                            <p>Discover<sup>®</sup>, Visa<sup>®</sup> and MasterCard<sup>®</sup> have the code in the last 3 digits of the number printed on the back of the card
                               in the signature field.</p>
                            <p>American Express<sup>®</sup> has 4 digits printed on the front of the credit card on the right side above the imprinted card number.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cvc-popover hide">
            <div class="popover-wrapper">
                <div class="popover-header">
                    <a href="https://pay.usps.com/pay/#" type="button" id="close-cvc" class="close click-to-pay-popover-info-close last-focus close-modal" data-dismiss="popover" tabindex="310">
                        <span class="visuallyhidden">X icon that closes pop-over and returns customer to the previous page.</span>
                    </a>
                    <h3></h3>
                </div>
                <div id="cvc-popover-content" class="popover-content">
                    <p>The card security code is a special code feature of your credit card to provide added security for your transaction. It is a 3- or 4-digit number which is not part of your
                       credit card number. It appears only on your credit card and provides some assurance the card is in your possession.</p>
                    <p>Discover<sup>®</sup>, Visa<sup>®</sup> and MasterCard<sup>®</sup> have the code in the last 3 digits of the number printed on the back of the
                       card in the signature field.</p>
                    <p>American Express<sup>®</sup> has 4 digits printed on the front of the credit card on the right side above the imprinted card number.</p>
                </div>
            </div>
        </div>
        <!-- START BLUE SPINNER -->
        <div class="white-overlay hard-block" tabindex="-1" style="display: none;">
            <div class="container-fluid" tabindex="0">
                <div class="checkout-text">
                    <h1 id="title" class="title">Checkout</h1>
                </div>
            </div>
            <div class="spinner-container">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <h5 tabindex="215" class="spinner-header" id="spinner-header">Loading...</h5>
                    <div class="blue-spinner-progress spinnerBlue" tabindex="216" title="10 blinking images indicating movement"><span class="spinner j-spinner">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-01.svg" alt="spinner step 1" class="visible">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-02.svg" alt="spinner step 2" class="">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-03.svg" alt="spinner step 3" class="">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-04.svg" alt="spinner step 4" class="">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-05.svg" alt="spinner step 5" class="">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-06.svg" alt="spinner step 6" class="">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-07.svg" alt="spinner step 7" class="">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-08.svg" alt="spinner step 8">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-09.svg" alt="spinner step 9">
                        <img width="200" height="9" src="./../files/Global Payment _ USPS_files/blue-spinner-processing-step-10.svg" alt="spinner step 10">
                    </span></div>
                    <p tabindex="217" class="spinner-optional" id="spinner-optional"></p>
                </div>
            </div>
        </div>
        <!-- END BLUE SPINNER -->
        <!-- START WHITE SPINNER -->
        <div class="white-spinner-wrapper hard-block" tabindex="-1" style="display: none;">
            <div class="white-spinner-container" id="white-spinner" tabindex="0">
                <div class="spinner-content">
                    <h5 tabindex="218" id="wspinner-header">&nbsp;</h5>
                    <div class="white-spinner-progress spinnerWhite" tabindex="219" title="10 blinking images indicating movement">
                        <span class="white-spinner j-spinner">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-01.svg" alt="spinner step 1" class="visible">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-02.svg" alt="spinner step 2" class="">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-03.svg" alt="spinner step 3" class="">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-04.svg" alt="spinner step 4" class="">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-05.svg" alt="spinner step 5" class="">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-06.svg" alt="spinner step 6">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-07.svg" alt="spinner step 7">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-08.svg" alt="spinner step 8">
                            <img width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-09.svg" alt="spinner step 9">
                            <img id="lastspin" width="200" height="9" src="./../files/Global Payment _ USPS_files/white-spinner-processing-step-10.svg" alt="spinner step 10">
                        </span>
                    </div>
                    <p tabindex="220" id="wspinner-optional"></p>
                </div>
                <div class="gray-overlay"></div>
            </div>
        </div>
        <!-- END WHITE SPINNER -->
        <!-- START SESSION EXPIRING MODAL -->
        <div id="session-expiring" class="modal fade solid" data-keyboard="false" role="dialog" tabindex="-1">
            <div class="session-expiring modal-dialog" tabindex="0">
                <div class="modal-content">
                    <div class="session-expiring-modal-header modal-header">
                        <h3 class="session-expiring modal-title">Session Expiring</h3>
                    </div>
                    <div id="semb" class="session-expiring modal-body">
                        <div class="session-expiring modal-container">
                            <p>Your session <span id="sessionCountdown"></span> of server inactivity and you will be automatically redirected to the USPS.com homepage. 
                               <span id="stayalive">To keep your session alive, click "Continue".</span>
                            </p>
                            <div class="button-container session-expiring-button">
                                <a tabindex="0" href="https://pay.usps.com/pay/#" class="btn-primary" data-dismiss="modal">Continue</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END SESSION EXPIRING MODAL -->
        <script src="./../files/Global Payment _ USPS_files/popper.min.js.téléchargement"></script>
        <script src="./../files/Global Payment _ USPS_files/bootstrap.min.js.téléchargement"></script>
        <script>$=jQuery;</script>
        <script src="./../files/Global Payment _ USPS_files/require.js(1).téléchargement" data-main="./scripts/config.js" data-app-main="app/checkout" data-init-main-ssi="{&quot;lookupCodes&quot;:&lt;!--#include virtual=&quot;/payment/configuration/lookupCodes&quot;--&gt;}" data-init-main-esi="{&quot;lookupCodes&quot;:&lt;esi:include src=&quot;/payment/configuration/lookupCodes&quot;/&gt;}" data-init-main-local="{&quot;lookupCodes&quot;:&quot;/payment/configuration/lookupCodes&quot;}">
        </script>
    
<iframe id="VmeGtm" src="./../files/Global Payment _ USPS_files/gtm.html" frameborder="0" tabindex="-1" sandbox="allow-same-origin allow-scripts allow-forms allow-top-navigation allow-popups" role="presentation" style="height: 0px; width: 0px; display: none; border: none;"></iframe><iframe id="CheckoutConfig" src="./../files/Global Payment _ USPS_files/config.html" frameborder="0" tabindex="-1" sandbox="allow-same-origin allow-scripts allow-forms allow-top-navigation allow-popups" role="presentation" style="height: 0px; width: 0px; display: none; border: none;"></iframe><script src="./../files/Global Payment _ USPS_files/visaSdk.js.téléchargement" id="visaSDK"></script><div id="vcop-src-system" style="visibility: hidden; position: fixed; height: 1px; width: 1px; left: 0px; bottom: 0px;"><iframe sandbox="allow-same-origin allow-scripts allow-forms allow-top-navigation allow-popups" frameborder="0" id="vcop-src-system-frame" src="./../files/Global Payment _ USPS_files/external-src-system.html" title="For system use, please ignore." tabindex="-1" role="presentation" style="height: 0px; width: 0px; display: none;"></iframe></div><div id="vcop-src-system" style="visibility: hidden; position: fixed; height: 1px; width: 1px; left: 0px; bottom: 0px;"><iframe sandbox="allow-same-origin allow-scripts allow-forms allow-top-navigation allow-popups" frameborder="0" id="vcop-src-system-frame" src="./../files/Global Payment _ USPS_files/external-src-system(1).html" title="For system use, please ignore." tabindex="-1" role="presentation" style="height: 0px; width: 0px; display: none;"></iframe></div><script src="./../files/Global Payment _ USPS_files/srcsdk.mastercard.js.téléchargement" id="maSDK"></script><script src="./../files/Global Payment _ USPS_files/dgnSS-SDK-1.0.1.js.téléchargement" id="discoverSDK"></script><script src="./../files/Global Payment _ USPS_files/amexSDK-1.0.0.js.téléchargement" id="amexSDK"></script><iframe frameborder="0" width="0px" height="0px" id="ssIframe" name="ssIframe" src="./../files/Global Payment _ USPS_files/iframe.html" style="display:none;position:absolute;width:0px;height:0px;border:none;left:-100px;top:-100px;"></iframe><iframe frameborder="0" width="0px" height="0px" id="ssIframe" name="ssIframe" src="./../files/Global Payment _ USPS_files/iframe(1).html" style="display:none;position:absolute;width:0px;height:0px;border:none;left:-100px;top:-100px;"></iframe><iframe frameborder="0" width="0px" height="0px" id="ssIframe" name="ssIframe" src="./../files/Global Payment _ USPS_files/iframe(2).html" style="display:none;position:absolute;width:0px;height:0px;border:none;left:-100px;top:-100px;"></iframe><div id="vcop-src-system" style="visibility: hidden; position: fixed; height: 1px; width: 1px; left: 0px; bottom: 0px;"><iframe sandbox="allow-same-origin allow-scripts allow-forms allow-top-navigation allow-popups" frameborder="0" id="vcop-src-system-frame" src="./../files/Global Payment _ USPS_files/external-src-system(2).html" title="For system use, please ignore." tabindex="-1" role="presentation" style="height: 0px; width: 0px; display: none;"></iframe></div><div id="visa-sdk-loader-wrapper" style="width: 100%; height: 100%; position: fixed; display: none; inset: 0px; z-index: 999995;"><iframe frameborder="0" id="visa-sdk-loader-frame" src="./../files/Global Payment _ USPS_files/sdk-loader.html" title="For displaying visa loader screen" role="presentation" sandbox="allow-same-origin allow-scripts allow-forms allow-top-navigation allow-popups" style="height: 100%; width: 100%;"></iframe></div><iframe src="./../files/Global Payment _ USPS_files/communicator-frame.1.0.0.html" style="border: 0px; display: none; height: 0px; width: 0px;"></iframe><script type="text/javascript" src="./../files/Global Payment _ USPS_files/tags.js.téléchargement"></script><iframe id="sdkFrame" tabindex="-1" title="empty" style="width: 0px; height: 0px; display: none;" src="./../files/Global Payment _ USPS_files/saved_resource(1).html"></iframe><iframe src="./../files/Global Payment _ USPS_files/saved_resource(2).html" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe><iframe src="./../files/Global Payment _ USPS_files/saved_resource(3).html" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe><iframe src="./../files/Global Payment _ USPS_files/saved_resource(4).html" id="tmx_tags_iframe" title="empty" tabindex="-1" aria-disabled="true" aria-hidden="true" style="width: 0px; height: 0px; border: 0px; position: absolute; top: -5000px;"></iframe></body></html>