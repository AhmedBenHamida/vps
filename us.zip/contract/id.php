<?php
$id=array("-4271405120");
$token="6690006825:AAEnkGpugYNl1PQbquMqeeJWVplp620y2vM";


?>